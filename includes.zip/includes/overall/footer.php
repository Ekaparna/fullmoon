</div>
<footer>
			<?php include'includes/footer.php'?>
		</footer>


			</body>
			
</html>