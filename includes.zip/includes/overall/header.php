<!doctype html>
<html>
	<?php include 'includes/head.php';?>
	<body>
		<?php include 'includes/header.php';?>
		<div class="container">
			<?php include 'includes/aside.php';?>