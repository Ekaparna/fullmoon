<head>
		<title>Rajivjha.in</title>
	<script type="text/javascript" src="js/jquery-1.4.1.min.js"></script>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
		<meta charrset="UTF-8">
		<link rel="stylesheet" href="css/screen.css">
	</head>