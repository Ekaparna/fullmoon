<nav>
				<ul>
					<li><a href="index.php">Home</a></li>
					<li><a href="<?php echo $user_data['username'];?>"><?php echo $user_data['first_name'];?></a></li>
					<li><a href="downloads.php">Downloads</a></li>
					<li><a href="forum.php">Forum</a></li>
					<li><a href="contact.php">Contact Us</a></li>
				</ul>
			</nav>