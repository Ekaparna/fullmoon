<?php

?><br>
<a href="deactivate.php">Deactivate</a>