<div class="widget">
					<h2>Log in/Register</h2>
					<div class="inner">
						<form action="login.php" method="POST">
					 <ul id= "login" style="list-style: none;">
					     
						 <li>User name: <br>
						 <input type="text" name="username">
						 </li>
						 <li>Or
						 </li>
					     <li>Email Id: <br>
						 <input type="email" name="email">
						 </li>
						 <li>Password :<br>
						 <input type="password" name="password">
						 </li>
					     
						 <li>
						 <input type="submit" value="Log in">
						 </li>
						 
					     <li>
						 <a href="register.php">Register</a>
						 </li>
					     <li>
						 Forgotten your  <br><a href="recover.php?mode=username">Username</a>/<a href="recover.php?mode=password">Password</a>
						 </li>
					 </ul>
					 </form>
					</div>
				</div> 