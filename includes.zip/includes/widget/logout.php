<?php

?><br>
<a href="logout.php">Logout</a>