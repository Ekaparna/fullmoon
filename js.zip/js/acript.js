$(document).ready(function(){

$('.chat_head').click(function(){
	$('.chat_body').hide();
});
});