<aside>
				<div class="widget">
					<h2>Widget Header</h2>
					<div class="inner">
					Widget Contents
					</div>
				</div>
			</aside>