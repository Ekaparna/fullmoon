<?php include'includes/overall/header.php';?>
			
			<h1>Home</h1>
			<p>Just a Template.</p>
<?php include 'includes/overall/footer.php';?>
		
