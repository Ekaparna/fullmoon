<?php 
include'core/init.php';
include'includes/overall/header.php';?>
			<h1>Thorough fare is not allowed.</h1>
			<p>Sorry, you need to be logged in to do that!</p>
			<p>Please register or login</p>


			
<?php include 'includes/overall/footer.php';?>

		