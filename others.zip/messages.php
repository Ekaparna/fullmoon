<?php

include'core/init.php';
protect_page();

include 'includes/overall/header.php';

?>