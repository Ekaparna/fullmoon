<?php 
include'core/init.php';
include'includes/overall/header.php';?>
			<h1>Only unlogged people are allowed.</h1>
			<p>Sorry, you need to logout to do that!</p>
			<p>Please logout or deactivate.</p>


			
<?php include 'includes/overall/footer.php';?>

		