<?php 
include'core/init.php';
protect_page();
admin_protect();

include'includes/overall/header.php';?>
			<h1>Admin Page</h1>
			<p>Just a Template.</p>


			
<?php include 'includes/overall/footer.php';
?>

		