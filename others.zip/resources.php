resources
developphp.com - time ago script program