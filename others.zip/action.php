<?php 
include'core/init.php';
protect_page();
	 
	session_start();
	
	$action= $_GET['action'];
	$user=$_GET['user'];//jiska username dala hai
	$type=$_GET['type'];//jiska username dala hai
	$id=$_GET['id'];//jiska username dala hai
	$user2=$session_user_id;//jo loggedin hai
			
$user_data =user_data($user,'first_name','last_name','email','username','profile','enrollment_id','gender','age','type');
if($type=='post'){
	if($action=='upvote'){
			if(user_post_upvote_exists($user2,$id) === 1){
					$con->query("DELETE FROM upvote_post WHERE `who_id`='$user2' AND `post_id`='$id' ");
			
			}
			else if(user_post_downvote_exists($user2,$id) === 1){
					$con->query("DELETE FROM downvote_post WHERE `who_id`='$user2' AND `post_id`='$id' ");
			$con->query("INSERT INTO upvote_post VALUES('','$user2','$id' )");
			
			}
			else{
				$con->query("INSERT INTO upvote_post VALUES('','$user2','$id' )");
			
			}
			}
	
	else if($action=='downvote'){
		
		
			if(user_post_downvote_exists($user2,$id) === 1){
					$con->query("DELETE FROM downvote_post WHERE `who_id`='$user2' AND `post_id`='$id' ");
			
			}
			else if(user_post_upvote_exists($user2,$id) === 1){
					$con->query("DELETE FROM upvote_post WHERE `who_id`='$user' AND `post_id`='$id' ");
			$con->query("INSERT INTO downvote_post VALUES('','$user2','$id' )");

			}
			else{
				$con->query("INSERT INTO downvote_post VALUES('','$user2','$id' )");
			
			}
			}
				
				}
				

				

	header('location: profile.php?username='.$user_data['username']);
	
	
	
	?>