<?php
aaja mere humdam peele rum mere sang
yaad rakh re chokre , career ne na tujhse kehna 
tu mera bhaiya mai teri behna
meri raatein to aaj tak soyi hi nhi hai, mai kya sounga
my mom blessed me today "may almight  bless each night of mine a fullmoon night, she didn't knew someone has made that fullmoon a curse for me."
God listened her . Every night of mine is now fullmoon.
?>