<?php 
include'core/init.php';
include'includes/overall/header.php';?>
			<h1>Contact Us</h1>
			<p>Just a Template.</p>
<?php include 'includes/overall/footer.php';?>